#include "utils.h"

/* */
int partition (int A[], int left, int right) {
  /*Terminar: ver aula!*/	
}

/* */
void quick_find (int *A, int left, int right, int k) {
  /*Terminar!*/	
}

/* */
int main () {
  int n = 8;
  int A[] = {7, 1, 3, 10, 17, 2, 21, 9};
  print (A, n, "Input");
  quick_find (A, 0, n-1, 4);
  print (A, n, "Partial sorted");
  return 0;
}
