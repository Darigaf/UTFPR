#include "queue.h"

int main () {
  int i, n = 10;	
  /*Use somente as operações definidas em queue.h*/
  /*Não use para resolver esse exercício o operador -> aqui!*/
  /*Terminar*/
  return 0;
}

