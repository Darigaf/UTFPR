#include "queue.h"
#include <time.h>

void jackpot (int n, int r) {
  /*Terminar*/
}

int main () {
  srand(time(NULL));	
  int n = 3;  /*número de carretéis*/ 
  int r = 10; /*sequência de números em cada carretel*/ 
  jackpot (n, r);
}
