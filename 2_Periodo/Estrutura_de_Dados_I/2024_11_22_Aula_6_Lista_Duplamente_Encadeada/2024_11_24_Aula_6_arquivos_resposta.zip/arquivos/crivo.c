#include <math.h>
#include "list.h"

void crivo (int n) { 
  int i, sq = sqrt(n);       	
  List *l = create ();
  /*Terminar!*/
  destroy (l);
}   

int main () {
  int n = 30;
  crivo (n);
  return 0;
} 
